<?php
// controllers/RequerimientoController.php
require_once 'models/Requerimiento.php';
require_once 'models/Avance.php';
require_once 'models/Notificacion.php';
require_once 'models/Usuario.php';

class RequerimientoController {
    private $requerimientoModel;
    private $avanceModel;
    private $notificacionModel;
    private $usuarioModel;
    
    public function __construct() {
        $this->requerimientoModel = new Requerimiento();
        $this->avanceModel = new Avance();
        $this->notificacionModel = new Notificacion();
        $this->usuarioModel = new Usuario();
    }
    
    // Listar requerimientos
    public function index() {
        // Verificar si el usuario está logueado
        if (!isLoggedIn()) {
            redirect('login');
        }
        
        // Procesar filtros si existen
        $filtros = [];
        if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['filtrar'])) {
            if (!empty($_GET['estado'])) {
                $filtros['estado'] = sanitize($_GET['estado']);
            }
            if (!empty($_GET['prioridad'])) {
                $filtros['prioridad'] = sanitize($_GET['prioridad']);
            }
            if (!empty($_GET['fecha_desde'])) {
                $filtros['fecha_desde'] = sanitize($_GET['fecha_desde']);
            }
            if (!empty($_GET['fecha_hasta'])) {
                $filtros['fecha_hasta'] = sanitize($_GET['fecha_hasta']);
            }
        }
        
        // Obtener requerimientos según el rol
        if (isAdmin()) {
            $requerimientos = $this->requerimientoModel->listarTodos($filtros);
        } else {
            $requerimientos = $this->requerimientoModel->listarPorArea($_SESSION['area_id'], $filtros);
        }
        
        // Mostrar la vista
        include 'views/requerimientos/index.php';
    }
    
    // Mostrar formulario para crear requerimiento
    public function crear() {
        // Verificar si el usuario está logueado
        if (!isLoggedIn()) {
            redirect('login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Procesar el formulario
            
            // Sanitizar datos
            $titulo = sanitize($_POST['titulo']);
            $descripcion = sanitize($_POST['descripcion']);
            $prioridad = sanitize($_POST['prioridad']);
            
            // Validar datos
            $errores = [];
            
            if (empty($titulo)) {
                $errores[] = 'El título es obligatorio';
            }
            
            if (empty($descripcion)) {
                $errores[] = 'La descripción es obligatoria';
            }
            
            if (empty($prioridad)) {
                $errores[] = 'La prioridad es obligatoria';
            }
            
            // Si no hay errores, guardar requerimiento
            if (empty($errores)) {
                $data = [
                    'titulo' => $titulo,
                    'descripcion' => $descripcion,
                    'prioridad' => $prioridad,
                    'area_id' => $_SESSION['area_id'],
                    'creado_por' => $_SESSION['user_id']
                ];
                
                if ($this->requerimientoModel->crear($data)) {
                    setMessage('success', 'Requerimiento creado correctamente');
                    redirect('requerimientos');
                } else {
                    setMessage('error', 'Ocurrió un error al crear el requerimiento');
                }
            } else {
                // Si hay errores, mostrar de nuevo el formulario con los errores
                include 'views/requerimientos/crear.php';
            }
        } else {
            // Mostrar formulario
            include 'views/requerimientos/crear.php';
        }
    }
    
    // Ver detalle de requerimiento
    public function ver($id) {
        // Verificar si el usuario está logueado
        if (!isLoggedIn()) {
            redirect('login');
        }
        
        // Obtener requerimiento
        $requerimiento = $this->requerimientoModel->obtenerPorId($id);
        
        // Verificar si existe el requerimiento
        if (!$requerimiento) {
            setMessage('error', 'El requerimiento no existe');
            redirect('requerimientos');
        }
        
        // Verificar permisos (solo puede verlo el admin o usuarios de la misma área)
        if (!isAdmin() && $requerimiento['area_id'] != $_SESSION['area_id']) {
            setMessage('error', 'No tienes permisos para ver este requerimiento');
            redirect('requerimientos');
        }
        
        // Obtener avances del requerimiento
        $avances = $this->avanceModel->listarPorRequerimiento($id);
        
        // Mostrar vista
        include 'views/requerimientos/ver.php';
    }
    
    // Cambiar estado del requerimiento
    public function cambiarEstado($id) {
        // Verificar si el usuario está logueado y es administrador
        if (!isLoggedIn() || !isAdmin()) {
            redirect('login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Obtener y sanitizar el nuevo estado
            $estado = sanitize($_POST['estado']);
            
            // Obtener requerimiento actual para verificar si cambió a finalizado
            $requerimientoActual = $this->requerimientoModel->obtenerPorId($id);
            $estadoAnterior = $requerimientoActual['estado'];
            
            // Actualizar estado
            if ($this->requerimientoModel->actualizarEstado($id, $estado)) {
                // Si el estado cambió a "finalizado", crear notificación
                if ($estado == 'finalizado' && $estadoAnterior != 'finalizado') {
                    // Crear notificación para el creador del requerimiento
                    $notificacion = [
                        'usuario_id' => $requerimientoActual['creado_por'],
                        'mensaje' => 'Tu requerimiento "' . $requerimientoActual['titulo'] . '" ha sido marcado como finalizado.',
                        'requerimiento_id' => $id
                    ];
                    $this->notificacionModel->crear($notificacion);
                }
                
                setMessage('success', 'Estado actualizado correctamente');
            } else {
                setMessage('error', 'Ocurrió un error al actualizar el estado');
            }
            
            redirect('requerimientos/ver/' . $id);
        } else {
            redirect('requerimientos');
        }
    }
    
    // Editar requerimiento
    public function editar($id) {
        // Verificar si el usuario está logueado
        if (!isLoggedIn()) {
            redirect('login');
        }
        
        // Obtener requerimiento
        $requerimiento = $this->requerimientoModel->obtenerPorId($id);
        
        // Verificar si existe el requerimiento
        if (!$requerimiento) {
            setMessage('error', 'El requerimiento no existe');
            redirect('requerimientos');
        }
        
        // Verificar permisos (solo pueden editarlo el admin o el creador)
        if (!isAdmin() && $requerimiento['creado_por'] != $_SESSION['user_id']) {
            setMessage('error', 'No tienes permisos para editar este requerimiento');
            redirect('requerimientos');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Procesar formulario
            
            // Sanitizar datos
            $titulo = sanitize($_POST['titulo']);
            $descripcion = sanitize($_POST['descripcion']);
            $prioridad = sanitize($_POST['prioridad']);
            
            // Validar datos
            $errores = [];
            
            if (empty($titulo)) {
                $errores[] = 'El título es obligatorio';
            }
            
            if (empty($descripcion)) {
                $errores[] = 'La descripción es obligatoria';
            }
            
            if (empty($prioridad)) {
                $errores[] = 'La prioridad es obligatoria';
            }
            
            // Si no hay errores, actualizar requerimiento
            if (empty($errores)) {
                $data = [
                    'id' => $id,
                    'titulo' => $titulo,
                    'descripcion' => $descripcion,
                    'prioridad' => $prioridad
                ];
                
                if ($this->requerimientoModel->actualizar($data)) {
                    setMessage('success', 'Requerimiento actualizado correctamente');
                    redirect('requerimientos/ver/' . $id);
                } else {
                    setMessage('error', 'Ocurrió un error al actualizar el requerimiento');
                }
            } else {
                // Si hay errores, mostrar de nuevo el formulario con los errores
                include 'views/requerimientos/editar.php';
            }
        } else {
            // Mostrar formulario
            include 'views/requerimientos/editar.php';
        }
    }
    
    // Eliminar requerimiento
    public function eliminar($id) {
        // Verificar si el usuario está logueado y es administrador
        if (!isLoggedIn() || !isAdmin()) {
            redirect('login');
        }
        
        // Intentar eliminar
        if ($this->requerimientoModel->eliminar($id)) {
            setMessage('success', 'Requerimiento eliminado correctamente');
        } else {
            setMessage('error', 'Ocurrió un error al eliminar el requerimiento');
        }
        
        redirect('requerimientos');
    }
}
?>

