// assets/js/chart.js

/**
 * Scripts para gráficas del dashboard
 */

document.addEventListener('DOMContentLoaded', function() {
    // Esta función se completará automáticamente en el dashboard
    // con los datos específicos de cada usuario
});