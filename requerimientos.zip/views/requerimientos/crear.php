<?php
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../../config/config.php';
}
?>
<?php
// views/requerimientos/crear.php
include 'views/templates/header.php';
?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-plus-circle me-2"></i> Nuevo Requerimiento
        </h5>
    </div>
    <div class="card-body">
        <form action="<?= BASE_URL ?>requerimientos/crear" method="post">
            <div class="mb-3">
                <label for="titulo" class="form-label">Título <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="titulo" name="titulo" required 
                    placeholder="Escribe un título descriptivo" value="<?= $_POST['titulo'] ?? '' ?>">
            </div>
            
            <div class="mb-3">
                <label for="descripcion" class="form-label">Descripción <span class="text-danger">*</span></label>
                <textarea class="form-control" id="descripcion" name="descripcion" rows="5" required
                    placeholder="Detalla tu requerimiento lo más específico posible"><?= $_POST['descripcion'] ?? '' ?></textarea>
            </div>
            
            <div class="mb-3">
                <label for="prioridad" class="form-label">Prioridad <span class="text-danger">*</span></label>
                <select class="form-select" id="prioridad" name="prioridad" required>
                    <option value="baja" <?= isset($_POST['prioridad']) && $_POST['prioridad'] == 'baja' ? 'selected' : '' ?>>Baja</option>
                    <option value="media" <?= !isset($_POST['prioridad']) || $_POST['prioridad'] == 'media' ? 'selected' : '' ?>>Media</option>
                    <option value="alta" <?= isset($_POST['prioridad']) && $_POST['prioridad'] == 'alta' ? 'selected' : '' ?>>Alta</option>
                    <option value="urgente" <?= isset($_POST['prioridad']) && $_POST['prioridad'] == 'urgente' ? 'selected' : '' ?>>Urgente</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Área</label>
                <input type="text" class="form-control" disabled value="<?= $_SESSION['area_nombre'] ?? '' ?>">
                <div class="form-text">El requerimiento se registrará para tu área actual.</div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="<?= BASE_URL ?>requerimientos" class="btn btn-secondary me-md-2">
                    <i class="fas fa-times-circle me-2"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i> Guardar
                </button>
            </div>
        </form>
    </div>
</div>

<?php include 'views/templates/footer.php'; ?>

