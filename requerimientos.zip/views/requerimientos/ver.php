<?php
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../../config/config.php';
}
?>

<?php
// views/requerimientos/ver.php
include 'views/templates/header.php';
?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-primary text-white">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">
                <i class="fas fa-clipboard-list me-2"></i> Requerimiento #<?= $requerimiento['id'] ?>
            </h5>
            <div>
                <?php if (isAdmin() || $requerimiento['creado_por'] == $_SESSION['user_id']): ?>
                    <a href="<?= BASE_URL ?>requerimientos/editar/<?= $requerimiento['id'] ?>" class="btn btn-light btn-sm">
                        <i class="fas fa-edit me-1"></i> Editar
                    </a>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>requerimientos" class="btn btn-light btn-sm">
                    <i class="fas fa-arrow-left me-1"></i> Volver
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3"><?= $requerimiento['titulo'] ?></h4>
                <div class="card mb-4">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 text-muted">Descripción:</h6>
                        <p class="card-text"><?= nl2br($requerimiento['descripcion']) ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">Información</h6>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Estado:</span>
                                <span class="badge bg-<?= 
                                    $requerimiento['estado'] == 'pendiente' ? 'warning' : 
                                    ($requerimiento['estado'] == 'en proceso' ? 'info' : 'success')
                                ?> py-2"><?= ucfirst($requerimiento['estado']) ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Prioridad:</span>
                                <span class="badge bg-<?= 
                                    $requerimiento['prioridad'] == 'baja' ? 'secondary' : 
                                    ($requerimiento['prioridad'] == 'media' ? 'primary' : 
                                    ($requerimiento['prioridad'] == 'alta' ? 'danger' : 'dark'))
                                ?> py-2"><?= ucfirst($requerimiento['prioridad']) ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Área:</span>
                                <span><?= $requerimiento['area_nombre'] ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Solicitado por:</span>
                                <span><?= $requerimiento['creado_por_nombre'] ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Fecha de creación:</span>
                                <span><?= date('d/m/Y H:i', strtotime($requerimiento['created_at'])) ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <?php if (isAdmin()): ?>
                    <div class="card mb-3">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">Cambiar Estado</h6>
                        </div>
                        <div class="card-body">
                            <form action="<?= BASE_URL ?>requerimientos/cambiar-estado/<?= $requerimiento['id'] ?>" method="post">
                                <div class="mb-3">
                                    <select name="estado" class="form-select" required>
                                        <option value="pendiente" <?= $requerimiento['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                        <option value="en proceso" <?= $requerimiento['estado'] == 'en proceso' ? 'selected' : '' ?>>En Proceso</option>
                                        <option value="finalizado" <?= $requerimiento['estado'] == 'finalizado' ? 'selected' : '' ?>>Finalizado</option>
                                    </select>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i> Actualizar Estado
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Avances -->
        <div class="mt-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5>Avances y Seguimiento</h5>
                <?php if (isAdmin()): ?>
                    <a href="<?= BASE_URL ?>avances/crear/<?= $requerimiento['id'] ?>" class="btn btn-success btn-sm">
                        <i class="fas fa-plus-circle me-2"></i> Registrar Avance
                    </a>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($avances)): ?>
                <div class="list-group">
                    <?php foreach ($avances as $avance): ?>
                        <div class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?= $avance['usuario_nombre'] ?></h6>
                                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($avance['created_at'])) ?></small>
                            </div>
                            <p class="mb-1"><?= nl2br($avance['descripcion']) ?></p>
                            <?php if (isAdmin()): ?>
                                <div class="d-flex justify-content-end mt-2">
                                    <button type="button" class="btn btn-danger btn-sm" 
                                        data-bs-toggle="modal" data-bs-target="#eliminarAvanceModal<?= $avance['id'] ?>">
                                        <i class="fas fa-trash-alt me-1"></i> Eliminar
                                    </button>
                                    
                                    <!-- Modal de confirmación para eliminar avance -->
                                    <div class="modal fade" id="eliminarAvanceModal<?= $avance['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header bg-danger text-white">
                                                    <h5 class="modal-title">Confirmar eliminación</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    ¿Estás seguro de que deseas eliminar este avance?
                                                    <p class="text-danger mt-2">Esta acción no se puede deshacer.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                    <a href="<?= BASE_URL ?>avances/eliminar/<?= $avance['id'] ?>" class="btn btn-danger">Eliminar</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i> Aún no hay avances registrados para este requerimiento.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'views/templates/footer.php'; ?>
